package com.example.Navigasidengandata.model

data class RencanaStudi(
    val namaMK: String = "",
    val kelas: String = ""
)