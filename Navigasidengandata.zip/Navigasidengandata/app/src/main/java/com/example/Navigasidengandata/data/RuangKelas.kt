package com.example.Navigasidengandata.data

object RuangKelas {
    val kelas = listOf(
        "A",
        "B",
        "C",
        "D",
    )
}