package com.example.Navigasidengandata.model

data class Mahasiswa(
    val nim : String ="",
    val nama : String ="",
    val email : String =""
)