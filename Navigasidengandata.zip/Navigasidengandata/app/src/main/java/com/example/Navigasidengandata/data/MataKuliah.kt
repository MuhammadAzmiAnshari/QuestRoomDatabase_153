package com.example.Navigasidengandata.data

object MataKuliah {
    val options = listOf(
        "Pemrograman Aplikasi Mobile Lanjut",
        "Pemrograman Aplikasi Web Framework",
        "Prototyping",
        "Aplikasi Multimedia",
        "Kecerdasaran Buatan",
        "Computer Vision"
    )

}